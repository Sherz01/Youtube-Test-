﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenQA.Selenium;
using SeleniumExtras.PageObjects;

namespace YoutubeTest.PageObjects
{
    public class ResultPage
    {

        IWebDriver driver;
        public ResultPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.CssSelector, Using = "#inline-title-icon>yt-icon")]
        public IWebElement ChannelNameText { get; set; }

        public ChannelPage NavigateToChannelPage()
        {
            ChannelNameText.Click();
            return new ChannelPage(driver);
        }
    }
}
