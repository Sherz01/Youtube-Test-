﻿using OpenQA.Selenium;
using SeleniumExtras.PageObjects;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace YoutubeTest.PageObjects
{
    public class ChannelPage
    {

        IWebDriver driver;
        public ChannelPage(IWebDriver driver)
        {
            this.driver = driver;
            PageFactory.InitElements(driver, this);
        }

        [FindsBy(How = How.CssSelector, Using = "#link-inherit-color")]
        public IWebElement ChannelName { get; set; }

        //public String GetChannelName()
        //{
        //    return new ChannelName.Text;
        //}
    }
}
