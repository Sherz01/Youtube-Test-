﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using SeleniumExtras.PageObjects;
using YoutubeTest.PageObjects;
using OpenQA.Selenium.Chrome;


namespace YoutubeTest.TestScripts
{
    [TestFixture]
    public class Module1 : BaseTest
    {
        [Test]
        public void OpenChannelTest()
        {
            var homePage = new HomePage(driver);
            Thread.Sleep(3000);
            var resultPage = homePage.NavigateToResultPage();

;        }
    }
}
